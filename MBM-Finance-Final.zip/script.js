function applyNow() {
  alert("Loan application portal coming soon!");
}